
<p align="center">
  <img src="BrandingAssets/SwastickArena_Logo.png" alt="Swastik Arena Logo" width="300"/>
</p>

<h1 align="center">🔱 Swastick Arena – Official Multiplayer Battle Game</h1>

<p align="center">
A chakra-based Indian multiplayer survival game featuring Swastik pass, XP ranks, and more.
</p>
